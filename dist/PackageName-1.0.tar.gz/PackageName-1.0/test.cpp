#include <iostream>
using namespace std;


int main()
{
  cout<<"Hellooooo Jani"<<endl;
}
